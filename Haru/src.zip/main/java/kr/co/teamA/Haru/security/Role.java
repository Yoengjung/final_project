package kr.co.teamA.Haru.security;

public enum Role {
    ADMIN, USER
}
