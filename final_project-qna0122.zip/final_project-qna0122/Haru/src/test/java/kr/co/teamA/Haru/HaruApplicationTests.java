package kr.co.teamA.Haru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaruApplicationTests {

	@Test
	void contextLoads() {
	}

}
