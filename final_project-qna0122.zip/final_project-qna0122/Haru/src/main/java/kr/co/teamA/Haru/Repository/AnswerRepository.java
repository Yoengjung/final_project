package kr.co.teamA.Haru.Repository;

import kr.co.teamA.Haru.Entity.Answer2;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer2, Integer> {

}
