package kr.co.teamA.Haru.Controller.board;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyBoardController {
    //@Autowired
    //private MyBoardService service;

//    @GetMapping("/boardList")
//    public List<BoardVO> listboard() {
//        return service.selectBoardList();
//    }
//    @PostMapping("/boardAdd")
//    public int  addBoard(@RequestBody BoardVO vo){
//        int res = service.insertBoard(vo);
//        return res;
//    }
}
