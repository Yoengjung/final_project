package kr.co.teamA.Haru.Controller.board;
import java.util.List;

import kr.co.teamA.Haru.Controller.board.BoardVO;

public interface BoardDao {
//    public List<BoardVO> selectList();
//
//    public int addBoard(BoardVO vo);
}
