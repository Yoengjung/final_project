package kr.co.teamA.Haru.Controller.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyBoardService {
  //  @Autowired
  //  private BoardDao dao;

//    public List<BoardVO> selectBoardList(){
//        return dao.selectList();
//    }

//    public int insertBoard(BoardVO vo){
//        return dao.addBoard(vo);
//    }
}